from flask import Flask, render_template, request, redirect, url_for, session, flash
import requests
from functools import wraps

app = Flask(__name__)
app.secret_key = "replace_with_a_random_secret"  # change this for production

# Simple user store (replace with DB or env vars in production)
USERS = {
    "admin": "password123",   # example credentials (change these)
    "staff": "staffpass"
}

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        # Basic authentication check
        if USERS.get(username) and USERS[username] == password:
            session["user"] = username
            flash(f"Welcome, {username}!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password", "danger")
            return render_template("login.html")
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user", None)
    flash("Logged out successfully", "info")
    return redirect(url_for("login"))

@app.route("/", methods=["GET"])
@login_required
def dashboard_redirect():
    return redirect(url_for("dashboard"))

@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    recipes = []
    searched = False
    message = None

    if request.method == "POST":
        searched = True
        query = request.form.get("query", "").strip()
        if not query:
            message = "Please enter an ingredient or recipe name."
        else:
            api_key = "c1d13a89d7d24d6cad42f786b4942d99"  # your spoonacular key
            url = f"https://api.spoonacular.com/recipes/complexSearch?query={query}&number=12&apiKey={api_key}"
            try:
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    recipes = data.get("results", [])
                else:
                    message = f"Spoonacular returned status {response.status_code}."
            except Exception as e:
                message = "Failed to connect to Spoonacular API."
                print("API error:", e)

    return render_template(
        "dashboard.html",
        recipes=recipes,
        searched=searched,
        message=message,
        user=session.get("user")
    )

if __name__ == "__main__":
    app.run(debug=True)
